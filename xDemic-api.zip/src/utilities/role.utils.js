module.exports = {
    Admin: 'Admin',
    Employee: 'Employee'
}