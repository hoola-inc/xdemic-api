# Xdemic-api

[ServerURL](https://xdemic-api.herokuapp.com "ServerURL")